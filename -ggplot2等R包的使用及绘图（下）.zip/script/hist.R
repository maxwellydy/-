library(ggplot2)
# Histogram on a Continuous (Numeric) Variable
g <- ggplot(mpg, aes(displ)) + 
  scale_fill_brewer(palette = "Set1")
g + geom_histogram(aes(fill=class), 
                   binwidth = .1, 
                   size=.1) 

