install.packages("devtools")
library(devtools)
install_github('lchiffon/REmap')
install.packages("REmap")
library("REmap")
all_name <- mapNames("world")#world map
data <- read.csv('data/data.csv',head=T)
name=data$name2
all=data.frame(name=all_name,num=0)
id=intersect(all$name,data$name2)
all_overlap=all[match(id,all$name),]
data=data[match(id,data$name2),]
id2=setdiff(all$name,data$name2)
all_unique=all[all$name %in% id2,]
all_overlap$num=data$data
all_unique$num=0
all=rbind(all_overlap,all_unique)
all$num=all$num/10000
all$num=log(all$num+1)
#��������ͼ
remapC(all,maptype="world",color=c("red","yellow","green","white"),mindata=0)
remapC(all,maptype="world",color=c("red","yellow","green","gray"),mindata=0)
remapC(all,maptype="world",color=c("red","purple","blue","green","orange","gray")
       ,mindata=0)




