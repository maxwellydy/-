library(tseries)
setwd("G:/R����/2-7.27")
data=read.table("data/time-series.txt",sep="\t",head=T)
plot.ts(data[,-1],main="Time series")


data$Time=as.character(data$Time)
ggplot(data, aes(x=Time)) + 
  geom_line(aes(y=Series.1)) + 
  labs(title="Monthly Time Series", 
       subtitle="Returns Percentage from Economics Dataset", 
       caption="Source: Economics", 
       y="Returns %") +  # title and caption
  scale_x_date(labels = lbls, 
               breaks = brks) 

library(ggplot2)
install.packages("lubridate")
library(lubridate)
theme_set(theme_bw())

data("economics")
economics_m <- economics[1:24, ]

# labels and breaks for X axis text
lbls <- paste0(month.abb[month(economics_m$date)], " ", 
               lubridate::year(economics_m$date))
brks <- economics_m$date

# plot
ggplot(economics_m, aes(x=date)) + 
  geom_line(aes(y=unemploy),col="blue") + 
  labs(title="Monthly Time Series",
       y="unemploy") + 
  scale_x_date(labels = lbls, 
               breaks = brks) +
  theme(axis.text.x = element_text(angle = 90),  
        panel.grid.minor = element_blank())  
