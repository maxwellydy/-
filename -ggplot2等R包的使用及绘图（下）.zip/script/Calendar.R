library(ggplot2)
library(plyr)
library(scales)
library(zoo)

df <- read.table("data/E.coli.calendar.xls",sep="\t",head=T)
df$date <- as.Date(df$date)  # format date
df <- df[df$year >= 2013, ]  # filter reqd years

# Create Month Week
df$yearmonth <- as.yearmon(df$date)
df$yearmonthf <- factor(df$yearmonth)
df <- ddply(df,.(yearmonthf), transform, monthweek=1+week-min(week))  
df <- df[, c("year", "yearmonthf", "monthf", 
             "week", "monthweek", "weekdayf", "E.coli")]
# Plot
ggplot(df, aes(monthweek, weekdayf, fill =E.coli )) + 
  geom_tile(colour = "white") + 
  facet_grid(year~monthf) + 
  scale_fill_gradient(low="blue", high="red") +
  labs(x="Week of Month",
       y="",
       title = "Time-Series Calendar Heatmap", 
       fill="E.coli")    
