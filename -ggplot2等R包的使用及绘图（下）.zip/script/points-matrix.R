####pairs
data=read.table("data/otu_table.Species.relative.txt",sep="\t",head=T,row.names=1,
                stringsAsFactors = F)
data=data[,-ncol(data)]
data=t(data)
data=data.frame(data)
data$group=c(rep("control",8),rep("model",8),rep("treat",8))
col=c(rep("blue",8),rep("green",8),rep("red",8))
pairs(data[,1:4],main="Species",pch=19,col=col)
###ggplot2
library(ggplot2)
library(GGally)
ggpairs(data, columns=1:4, aes(color=group)) + 
  ggtitle("species")
