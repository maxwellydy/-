library(ggplot2)
otu <- read.table("data/otu_table.Species.relative.txt", header=T, sep="\t",row.names=1)
otu=otu[order(otu$H1,decreasing = T),]
otu=otu[,-ncol(otu)]
otu=otu*100
data=stack(otu)
data$species=rep(row.names(otu),ncol(otu))

cols=c(brewer.pal(12,"Set3"),brewer.pal(12,"Paired"))
ggplot(data,aes(x=ind,y=values,fill=species))+geom_bar(stat="identity")+
  scale_fill_manual(values=cols)+labs(x="Sample",y="Percent")
