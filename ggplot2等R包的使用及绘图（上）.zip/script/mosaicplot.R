data(HairEyeColor)
ftable(HairEyeColor)
mosaicplot(~Hair+Eye+Sex,data=HairEyeColor,shade=TRUE,color=TRUE)
