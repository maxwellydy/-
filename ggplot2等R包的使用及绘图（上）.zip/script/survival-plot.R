library(survival)
data=read.table("data/fpkm_survival.xls",sep="\t",head=T,row.names=1)

group=c()
fpkm_median=median(data$fpkm)
for (i in 1:nrow(data))
{
  if (data$fpkm[i]<fpkm_median) {group[i]=1}
  if (data$fpkm[i]>=fpkm_median){group[i]=2 }
}

data=data.frame(data,group)
head(data)
data$X_OS=data$X_OS/30

######stat
######stat
km=survdiff(Surv(X_OS,X_OS_IND)~group,data=data)
p.value <- 1 - pchisq(km$chisq, length(km$n) - 1)
p=round(p.value,3)

##plot
my.fit<-survfit(Surv(X_OS,X_OS_IND)~group,data=data)
plot(my.fit,col=c("black","red"),xlab="Time (Months)",ylab="Overall survival rate",
     lwd=2) 
text=paste("Logrank P=",p,sep="")
text(max(data$X_OS*0.5),0.7,text)
low_n=sum(group==1)
high_n=sum(group==2)
low=paste("low expression of EGFR gene n=","(",low_n,")",sep="")
high=paste("high expression of EGFR gene n=","(",low_n,")",sep="")
legend("topright",legend=c(low,high),col=c("black","red"),cex=0.8,lty=1,
       lwd=2)


