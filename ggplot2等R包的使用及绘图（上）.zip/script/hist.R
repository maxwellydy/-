library("ggplot2")

data <- read.table("data/fpkm.txt",header=T)

allD <- stack(data)

m<-ggplot(allD,aes(x=values,fill=factor(ind)))
m + geom_density(alpha=0.5)+labs(fill="Sample")
