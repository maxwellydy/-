library(ggplot2)
library(ggcorrplot)

# Correlation matrix
data=read.table("data/expr.txt",sep="\t",head=T,row.names=1)
data=data[1:10,]
data=t(data)
corr <- round(cor(data), 1)

# Plot
ggcorrplot(corr, hc.order = TRUE, 
           type = "lower", 
           lab = TRUE, 
           lab_size = 3, 
           method="circle", 
           colors = c("tomato2", "white", "springgreen3"), 
           title="Correlogram of expression", 
           ggtheme=theme_bw) 