library(pheatmap)
data=read.table("data/otu_table.Family.absolute.txt",head=T,row.names=1)
data=data[1:20,]
data=data[,-ncol(data)]
data=as.matrix(data)
pheatmap(log10(data+1),border_color = "NA")
