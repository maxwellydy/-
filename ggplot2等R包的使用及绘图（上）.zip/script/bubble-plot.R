library(ggplot2)
data = read.table("data/DiffGene_GO_BP.txt",header=T,sep="\t")
# ��ͼ
pp = ggplot(data,aes(-log10(classicFisher),Term))
pp=pp + geom_point(aes(size=Significant,
                       color=-log10(classicFisher)))
# �Զ��彥����ɫ
pp + scale_colour_gradient(low="green",high="red") + labs(color="-log 10(P value)"
,size="Gene number", x="-log10 (P value)",y="GO Term",title="Top20 of GO term enrichment")
