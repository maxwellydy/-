library(ggplot2)
data(iris)
p <- ggplot(data=iris,aes(x = Petal.Length,y = Petal.Width)) 
p + geom_point(aes(colour = Species)) + 
  labs(title = "Iris") +theme_classic() +
  annotate("text",x=2,y=2,label = "x2,y2")
