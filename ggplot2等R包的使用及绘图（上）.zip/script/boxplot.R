library("ggplot2")

data <- read.table("data/expr.txt",header=T,row.names=1)

allD <- stack(data)

m<-ggplot(allD,aes(factor(ind),values))
m + geom_boxplot(aes(fill=factor(ind)))+labs(fill="Sample",x="",y="FPKM")
