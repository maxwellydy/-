library(survivalROC)
setwd("G:/΢��ѵ/R����/1-7.20")
data=read.table("data/ROC-data.xls",sep="\t",head=T,row.names=1)
##TNM+lasso
roc=survivalROC(Stime=data$time, status=data$status, marker = data$stage+data$risk, predict.time = 10, method="KM")
plot(roc$FP, roc$TP, type="l", xlim=c(0,1), ylim=c(0,1), 
     xlab="False positive rate", ylab="True positive rate",
     main=paste("ROC curve (", "AUC = ",round(roc$AUC,3),")"), cex.main=1.3, cex.lab=1.2, cex.axis=1.2, font=1.2,lwd=1.5,col="red")
abline(0,1,col="gray")

