data(iris)
x=iris$Petal.Length
y=iris$Petal.Width
plot(x,y,xlab="Petal.Length",ylab="Petal.Width")

color_map=function(x){
 if (x=="setosa") {"blue"} else if (x=="versicolor") {"green"}
  else {"red"}
}
col=unlist(lapply(iris$Species,color_map))
plot(x,y,xlab="Petal.Length",ylab="Petal.Width",col=col,pch=19,main="Iris")
text(2,2,"x2 y2")
legend("topleft",legend=c("setosa","versicolor","virginica"),
       col=c("blue","green","red"),pch=19)
