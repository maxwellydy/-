library(survival)
library(rms)
setwd("G:/΢��ѵ/R����/1-7.20")
data=read.table("data/nomogram-data.xls",sep="\t",head=T,row.names=1,stringsAsFactors = F)
data=na.omit(data)
data$futime=data$futime/30

dd<-datadist(data);
options(datadist="dd")

f<-cph(Surv(futime,fustat==1)~age+gender+race + pathologic_T + pathologic_N +pathologic_M
       +cancerType,data=data,x=T,y=T,surv=TRUE)
surv <- Survival(f) 
surv1 <- function(x)surv(1*60,lp=x) 

nom <- nomogram(f, fun=list(surv1), lp=F, funlabel=c("5 year survival")) 
plot(nom)
