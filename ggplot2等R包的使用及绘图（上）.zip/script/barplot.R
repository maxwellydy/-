setwd("G:/΢��ѵ/R����/1-7.20")
library(RColorBrewer)
otu <- read.table("data/otu_table.Species.relative.txt", header=T, sep="\t",row.names=1)
otu=otu[order(otu$H1,decreasing = T),]
otu<-as.matrix(otu[,-ncol(otu)])
otu=otu*100
n=nrow(otu)
col=c(brewer.pal(12,"Set3"),brewer.pal(12,"Paired"))
par(mar=c(4,4,3,8))
barplot(otu,col=col,las=2,xlab="Sample",ylab="Percent")
legend(ncol(otu)+5,100, row.names(otu), bty="n",
       fill=col,xpd=T)

