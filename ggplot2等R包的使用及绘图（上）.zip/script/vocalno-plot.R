data=read.table("data/diffExpress-mRNA_all.xls",sep="\t",row.names=1,head=T)
color=c()
for (i in 1:nrow(data)){
  if (data$FDR[i] < 0.05 & data$logFC[i] >1){
    col="red"
  } else if (data$FDR[i] < 0.05 & data$logFC[i]<(-1)){
    col="green"
  } else {col="black"}
  color=c(color,col)
}
plot(data$logFC,-log10(data$FDR),col=color,xlab="logFC",ylab="-log10(FDR)",pch=19)
abline(h=-log10(0.05),v=c(-1,1),lty=2)
