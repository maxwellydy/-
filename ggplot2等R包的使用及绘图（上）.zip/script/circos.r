setwd("G:/΢��ѵ/R����/1-7.20")
library(RCircos)
data=read.csv("data/data-circos.csv",head=T)
data(UCSC.HG19.Human.CytoBandIdeogram)
cyto.info <- UCSC.HG19.Human.CytoBandIdeogram;
RCircos.Set.Core.Components(cyto.info, chr.exclude=NULL,tracks.inside=8)
###λ��
RCircos.Set.Plot.Area()
RCircos.Chromosome.Ideogram.Plot()
##��������
RCircos.Gene.Connector.Plot(plot_data,track.num=1, side="in",inside.pos=0.5);
RCircos.Gene.Name.Plot(plot_data,name.col=ncol(plot_data),track.num=2, side="in");
RCircos.Heatmap.Plot(plot_data, data.col=ncol(plot_data),track.num=5, side="in");
##���Ա�����
plot_data$baseMean_Paracarcinoma=data$baseMean_Paracarcinoma
RCircos.Heatmap.Plot(plot_data, data.col=ncol(plot_data),track.num=6, side="in");
RCircos.Histogram.Plot(plot_data, data.col=ncol(plot_data),track.num=6, side="in");

##����������
plot_data$baseMean_Tumor=data$baseMean_Tumor
RCircos.Heatmap.Plot(plot_data, data.col=ncol(plot_data),track.num=7, side="in");
RCircos.Histogram.Plot(plot_data, data.col=ncol(plot_data),track.num=7, side="in");
##���챶��
plot_data$foldChange=data$foldChange
plot_data$foldChange[which(plot_data$foldChange=="Inf")]=60
RCircos.Heatmap.Plot(plot_data, data.col=ncol(plot_data),track.num=8, side="in");
RCircos.Histogram.Plot(plot_data, data.col=ncol(plot_data),track.num=8, side="in");

